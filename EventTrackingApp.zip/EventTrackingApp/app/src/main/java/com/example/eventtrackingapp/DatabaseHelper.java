
package com.example.eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracking.db";
    private static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Store user accounts.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL)");

        // Store events belonging to individual users.

        db.execSQL("CREATE TABLE events (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "event_name TEXT NOT NULL, " +
                "event_date TEXT NOT NULL, " +
                "event_time TEXT, " +
                "event_location TEXT, " +
                "event_description TEXT, " +
                "event_count INTEGER DEFAULT 0, " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {

        // Preserve existing accounts and events.
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE events ADD COLUMN event_time TEXT");
            db.execSQL("ALTER TABLE events ADD COLUMN event_location TEXT");
            db.execSQL("ALTER TABLE events ADD COLUMN event_description TEXT");
        }
    }


    // Register a new account with a password hash.
    public boolean addUser(String username, String passwordHash) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", passwordHash);

        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Look up the stored password hash for login verification.
    public String getPasswordHash(String username) {
        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                "users",
                new String[]{"password_hash"},
                "username = ?",
                new String[]{username},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getString(0);
            }
        }

        return null;
    }


    public boolean addEvent(int userId, String name, String date,
                            String time, String location,
                            String description) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("user_id", userId);
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("event_location", location);
        values.put("event_description", description);
        values.put("event_count", 0);

        long result = db.insert("events", null, values);

        return result != -1;
    }


    public int getUserId(String username) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                "users",
                new String[]{"id"},
                "username = ?",
                new String[]{username},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        }

        return -1;
    }


    public Cursor getEvents(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                "events",
                new String[]{
                        "id AS _id",
                        "event_name",
                        "event_date",
                        "event_time",
                        "event_location",
                        "event_description"
                },
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id DESC"
        );
    }

    public boolean deleteEvent(int eventId, int userId) {

        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                "events",
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                }
        );

        return rowsDeleted > 0;
    }

    public boolean updateEvent(int eventId, int userId,
                               String name, String date,
                               String time, String location,
                               String description) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("event_location", location);
        values.put("event_description", description);

        int rowsUpdated = db.update(
                "events",
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                }
        );

        return rowsUpdated > 0;
    }

}
