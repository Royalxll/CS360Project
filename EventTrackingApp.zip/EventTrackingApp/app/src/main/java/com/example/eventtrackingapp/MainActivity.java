package com.example.eventtrackingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;
import android.database.Cursor;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.telephony.SmsManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private int currentUserId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect login screen components.
        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        // Initialize the SQLite database.
        DatabaseHelper databaseHelper = new DatabaseHelper(this);

        // LOGIN BUTTON
        buttonLogin.setOnClickListener(v -> {

            String username =
                    editUsername.getText().toString().trim();
            String password =
                    editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String storedHash =
                        databaseHelper.getPasswordHash(username);

                if (storedHash != null &&
                        PasswordHelper.verifyPassword(
                                password, storedHash)) {

                    currentUserId = databaseHelper.getUserId(username);

                    if (currentUserId == -1) {
                        Toast.makeText(this,
                                "Unable to load user account",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Toast.makeText(this,
                            "Login successful",
                            Toast.LENGTH_SHORT).show();

                    showEventsScreen();


                } else {
                    Toast.makeText(this,
                            "Invalid username or password",
                            Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                Toast.makeText(this,
                        "Login error",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // CREATE ACCOUNT BUTTON
        buttonCreateAccount.setOnClickListener(v -> {

            String username =
                    editUsername.getText().toString().trim();
            String password =
                    editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String passwordHash =
                        PasswordHelper.hashPassword(password);

                boolean created =
                        databaseHelper.addUser(username, passwordHash);

                if (created) {
                    Toast.makeText(this,
                            "Account created successfully",
                            Toast.LENGTH_SHORT).show();

                    // User can now log in.
                } else {
                    Toast.makeText(this,
                            "Username already exists",
                            Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                Toast.makeText(this,
                        "Account creation failed",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showEventsScreen() {

        setContentView(R.layout.activity_events);

        loadEvents();

        Button buttonAddEvent = findViewById(R.id.buttonAddEvent);
        Button buttonNotifications = findViewById(R.id.buttonNotifications);

        buttonAddEvent.setOnClickListener(v -> {
            showAddEventScreen();
        });

        buttonNotifications.setOnClickListener(v -> {
            showNotificationsScreen();
        });
    }


    private void showAddEventScreen() {

        setContentView(R.layout.activity_add_event);

        // Connect the event input fields.
        EditText editEventName =
                findViewById(R.id.editEventName);
        EditText editEventDate =
                findViewById(R.id.editEventDate);
        EditText editEventTime =
                findViewById(R.id.editEventTime);
        EditText editEventLocation =
                findViewById(R.id.editEventLocation);
        EditText editEventDescription =
                findViewById(R.id.editEventDescription);

        Button buttonSaveEvent =
                findViewById(R.id.buttonSaveEvent);
        Button buttonCancel =
                findViewById(R.id.buttonCancel);

        DatabaseHelper databaseHelper =
                new DatabaseHelper(this);

        // Save the event to SQLite.
        buttonSaveEvent.setOnClickListener(v -> {

            String name =
                    editEventName.getText().toString().trim();
            String date =
                    editEventDate.getText().toString().trim();
            String time =
                    editEventTime.getText().toString().trim();
            String location =
                    editEventLocation.getText().toString().trim();
            String description =
                    editEventDescription.getText().toString().trim();

            // Require an event name and date.
            if (name.isEmpty() || date.isEmpty()) {
                Toast.makeText(this,
                        "Enter an event name and date",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Ensure an account is logged in.
            if (currentUserId == -1) {
                Toast.makeText(this,
                        "Please log in first",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean saved = databaseHelper.addEvent(
                    currentUserId,
                    name,
                    date,
                    time,
                    location,
                    description
            );

            if (saved) {
                Toast.makeText(this,
                        "Event saved successfully",
                        Toast.LENGTH_SHORT).show();

                showEventsScreen();

            } else {
                Toast.makeText(this,
                        "Unable to save event",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Return without saving.
        buttonCancel.setOnClickListener(v -> {
            showEventsScreen();
        });
    }


    private void showNotificationsScreen() {

        setContentView(R.layout.activity_notifications);

        EditText editPhoneNumber =
                findViewById(R.id.editPhoneNumber);

        TextView textNotificationStatus =
                findViewById(R.id.textNotificationStatus);

        Button buttonEnableNotifications =
                findViewById(R.id.buttonEnableSms);

        Button buttonTestSms =
                findViewById(R.id.buttonTestSms);

        Button buttonBackToEvents =
                findViewById(R.id.buttonBackToEvents);

        // Display current SMS permission status.
        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED;

        textNotificationStatus.setText(
                permissionGranted
                        ? "Status: SMS permission granted"
                        : "Status: SMS notifications are disabled"
        );

        // Enable SMS notifications.
        buttonEnableNotifications.setOnClickListener(v -> {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );

            } else {

                textNotificationStatus.setText(
                        "Status: SMS permission granted"
                );

                Toast.makeText(
                        this,
                        "SMS permission already granted",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Send a test SMS.
        buttonTestSms.setOnClickListener(v -> {

            String phoneNumber =
                    editPhoneNumber.getText().toString().trim();

            if (phoneNumber.isEmpty()) {
                Toast.makeText(
                        this,
                        "Please enter a phone number",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "Enable SMS permission first",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            try {
                SmsManager smsManager =
                        getSystemService(SmsManager.class);

                if (smsManager == null) {
                    throw new IllegalStateException(
                            "SMS service unavailable"
                    );
                }

                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        "Event Tracker: This is a test SMS reminder.",
                        null,
                        null
                );

                Toast.makeText(
                        this,
                        "Test SMS submitted for sending",
                        Toast.LENGTH_SHORT
                ).show();

            } catch (Exception e) {

                Toast.makeText(
                        this,
                        "Unable to send test SMS",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Return to events.
        buttonBackToEvents.setOnClickListener(v -> {
            showEventsScreen();
        });
    }


    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            TextView status =
                    findViewById(R.id.textNotificationStatus);

            if (status != null) {
                boolean granted =
                        grantResults.length > 0 &&
                                grantResults[0] ==
                                        PackageManager.PERMISSION_GRANTED;

                status.setText(granted
                        ? "Status: SMS permission granted"
                        : "Status: SMS permission denied");
            }
        }
    }


    private void loadEvents() {

        LinearLayout eventsContainer =
                findViewById(R.id.eventsContainer);

        eventsContainer.removeAllViews();

        DatabaseHelper databaseHelper =
                new DatabaseHelper(this);

        try (Cursor cursor =
                     databaseHelper.getEvents(currentUserId)) {

            int nameIndex =
                    cursor.getColumnIndexOrThrow("event_name");
            int dateIndex =
                    cursor.getColumnIndexOrThrow("event_date");
            int idIndex =
                    cursor.getColumnIndexOrThrow("_id");

            while (cursor.moveToNext()) {
                int eventId = cursor.getInt(idIndex);
                String eventName = cursor.getString(nameIndex);
                String eventDate = cursor.getString(dateIndex);

                String eventTime = cursor.getString(
                        cursor.getColumnIndexOrThrow("event_time"));

                String eventLocation = cursor.getString(
                        cursor.getColumnIndexOrThrow("event_location"));

                String eventDescription = cursor.getString(
                        cursor.getColumnIndexOrThrow("event_description"));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                row.setPadding(8, 12, 8, 12);

                TextView nameView = new TextView(this);
                nameView.setText(eventName);
                nameView.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                2f));

                TextView dateView = new TextView(this);
                dateView.setText(eventDate);
                dateView.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1.5f));


                Button editButton = new Button(this);
                editButton.setText("Edit");
                editButton.setOnClickListener(v -> {
                    showEditEventScreen(
                            eventId,
                            eventName,
                            eventDate,
                            eventTime,
                            eventLocation,
                            eventDescription
                    );
                });
                editButton.setTextSize(10);
                editButton.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1f
                        )
                );

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");

                deleteButton.setOnClickListener(v -> {

                    new androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("Delete Event")
                            .setMessage("Are you sure you want to delete this event?")
                            .setPositiveButton("Delete", (dialog, which) -> {

                                boolean deleted = databaseHelper.deleteEvent(
                                        eventId, currentUserId);

                                if (deleted) {
                                    Toast.makeText(this,
                                            "Event deleted successfully",
                                            Toast.LENGTH_SHORT).show();

                                    loadEvents();
                                } else {
                                    Toast.makeText(this,
                                            "Unable to delete event",
                                            Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });

                deleteButton.setTextSize(10);
                deleteButton.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1f));

                row.addView(nameView);
                row.addView(dateView);
                row.addView(editButton);
                row.addView(deleteButton);

                eventsContainer.addView(row);
            }
        }
    }

    private void showEditEventScreen(
            int eventId,
            String name,
            String date,
            String time,
            String location,
            String description) {

        setContentView(R.layout.activity_add_event);

        EditText editName = findViewById(R.id.editEventName);
        EditText editDate = findViewById(R.id.editEventDate);
        EditText editTime = findViewById(R.id.editEventTime);
        EditText editLocation = findViewById(R.id.editEventLocation);
        EditText editDescription = findViewById(R.id.editEventDescription);

        Button buttonSave = findViewById(R.id.buttonSaveEvent);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        // Populate the form with the existing event details.
        editName.setText(name);
        editDate.setText(date);
        editTime.setText(time);
        editLocation.setText(location);
        editDescription.setText(description);

        buttonSave.setText("Update Event");

        buttonSave.setOnClickListener(v -> {

            String updatedName = editName.getText().toString().trim();
            String updatedDate = editDate.getText().toString().trim();
            String updatedTime = editTime.getText().toString().trim();
            String updatedLocation = editLocation.getText().toString().trim();
            String updatedDescription =
                    editDescription.getText().toString().trim();

            if (updatedName.isEmpty() || updatedDate.isEmpty()) {
                Toast.makeText(this,
                        "Event name and date are required",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper databaseHelper = new DatabaseHelper(this);
            boolean updated = databaseHelper.updateEvent(
                    eventId,
                    currentUserId,
                    updatedName,
                    updatedDate,
                    updatedTime,
                    updatedLocation,
                    updatedDescription
            );

            if (updated) {
                Toast.makeText(this,
                        "Event updated successfully",
                        Toast.LENGTH_SHORT).show();

                showEventsScreen();
            } else {
                Toast.makeText(this,
                        "Unable to update event",
                        Toast.LENGTH_SHORT).show();
            }
        });

        buttonCancel.setOnClickListener(v -> showEventsScreen());
    }

}